import User from "../models/User.js";




export const getUserProfile = async (userId) => {
    
  const user = await User.findById(userId).select("-password");
  if (!user) throw new Error("User not found");
  return user;
};
export const updateProfile = async (userId, updateData,file) => {
try {
  //  const  updateData= JSON.parse(Data);
  //  console.log(updateData,"from service")
  const user = await User.findById(userId)
// console.log(user)
  if (!user) {
    throw new Error("User not found");
  }


  // If image is provided

  if (req.file) {
    // Local storage example
    const imagePath = `/uploads/profile/${req.file.originalname}`;
  console.log(imagePath)
    user.profileImage = imagePath;
  }

  // Update only provided fields (PATCH behavior)
  if (updateData.name) user.name = updateData.name;
  if(updateData.username)user.username=updateData.username;
  if(updateData.gender)user.gender=updateData.gender;
  if (updateData.bio) user.bio = updateData.bio;
  if (updateData.phone)user.phone = updateData.phone;
  if(updateData.language)user.language= updateData.language
  await user.save();
  return user;
  
} catch (error) {
  console.log(error)
  return error
}
};

